const productsData = [
  {
    id: 1,
    name: "Product 1",
    category: "Category A",
    price: 10.99,
    stockQuantity: 100,
  },
  {
    id: 2,
    name: "Product 2",
    category: "Category B",
    price: 20.99,
    stockQuantity: 120,
  },
  {
    id: 3,
    name: "Product 3",
    category: "Category C",
    price: 9.99,
    stockQuantity: 200,
  },
  {
    id: 4,
    name: "Product 4",
    category: "Category D",
    price: 15.99,
    stockQuantity: 150,
  },
  // Add more products here as needed
];

export default productsData;
